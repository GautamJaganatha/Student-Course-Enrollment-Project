package com.Learning.SCEP_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScepBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
